import java.util.Scanner;
public class RandomNumberGuesser {
	public static void main(String[] args) {
		System.out.println("***Random Number Guesser***");
	
		Scanner keyboard = new Scanner(System.in);
		boolean active = true;

		while (active) {
			
			int maxGuess = 100, minGuess = 0, nextGuess;
			int number = RNG.rand();
			int count = 0;			
			
			System.out.print("Enter your first guess: ");
			nextGuess = keyboard.nextInt();
			count++;
			
			while (nextGuess != number) {
		
				while(!RNG.inputValidation(nextGuess, minGuess, maxGuess)) {
					nextGuess = keyboard.nextInt();
				}
			
				System.out.println("Number of guesses: " + count);
				if (nextGuess < number) {
					minGuess = nextGuess;
					System.out.println("Your guess is too low");
				}
			
				if (nextGuess > number) {
					maxGuess = nextGuess;
					System.out.println("Your guess is too high");
				}
			
				System.out.println("Enter your next guess between " + minGuess + " and " + maxGuess + ": ");
				nextGuess = keyboard.nextInt();
				count++;
			}
			System.out.println("Congratulations, you guessed correctly");
			System.out.println("Try again? (y or n)");
			keyboard.nextLine();
			active = "y".equals(keyboard.nextLine());
		}
	}
}
